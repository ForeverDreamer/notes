from constants.share import ASSETS_DIR

ASSETS_DIR = ASSETS_DIR + '/数据结构与算法/力扣/剑指 Offer（第 2 版）/07. 重建二叉树'