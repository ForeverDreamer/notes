from datetime import datetime as dt


def now():
    return dt.now()
